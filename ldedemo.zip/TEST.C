
void test_normal(int a,int b,int c) // subroutine external to permutated code
{
  printf("test_normal(): normal,     called from "\
         "test_main(), params: %i %i %i\n",a,b,c);
}

void test_before() {}               // permutate from ...

void test_perm(int a,int b,int c)   // called from test_main()
{
  printf("test_perm():   permutated, called from "\
         "test_main(), params: %i %i %i\n",a,b,c);
}

void test_main()                    // called when permutated
{
  printf("test_main() works! it is permutated and called from normal code\n");
  for (int i=0, j=0; i<=20; i++, j=i*i)
    printf("%i%c",j, i==20?'\n':' ');
  test_perm(1,2,3);
  test_normal(4,5,6);
}

void test_after() {}                // ... permutate to

