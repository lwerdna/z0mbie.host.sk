
// LDE32 interface

extern "C" void pascal DISASM_INIT(void* tableptr);
extern "C" int  pascal DISASM_MAIN(void* opcodeptr, void* tableptr);

char tbl[2048];

void disasm_init()
{
  DISASM_INIT(&tbl);
}

int cdecl disasm(void* x)
{
  return DISASM_MAIN(x, &tbl);
}
