/*
   LDE32 Demo   1.00    FREEWARE        by Z0MBiE, http://z0mbie.cjb.net
   made in Moscow, Russia

   This program permutates own subroutine and then executes it.
   Sources may be used in permutating engine.

   disasm.c     -- LDE32 interface stuff (lde32.obj needed)
   random.c     -- fuckin randomer
   engine.c     -- simple permutating engine
   test.c       -- subroutines to permutate
   demo.c       -- this source

   demo.log     -- result of this program execution
   _icode       -- analyzed code, unused instructions filled with 0xCC
   _imap        -- map of analyzed code (i.e. ids for each byte)
   _ocode       -- resulting (permutated) code
*/

#include <stdio.h>
#include <stdlib.h>

typedef unsigned long DWORD;
typedef unsigned char BYTE;
typedef unsigned short WORD;

typedef void voidproc();

#include "disasm.c"
#include "random.c"
#include "engine.c"
#include "test.c"

void main()
{
  disasm_init();

  BYTE obuf[2048];
  DWORD oentry;

  int result =
  engine((BYTE*)test_before,                           // ibuf
         (DWORD)test_after-(DWORD)test_before+10,      // isize
         (DWORD)test_main-(DWORD)test_before,          // ientry (relative)
         obuf,                                         // obuf
         sizeof(obuf),                                 // osize (max)
         &oentry,                                      // *oentry
         disasm);                                      // disasm subroutine

  if (!result) return;

  printf("executing permutated code...\n\n");

  voidproc *x = (voidproc*)((DWORD)obuf+oentry);
  x();

  printf("\nsuccess!\n");

} //main
