
/*
                       ��񡪠 ����஫쭮� �㬬� �� ����
                       ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

  �������� 䠩� TARGETFILE ⠪, �⮡� ����஫쭠� �㬬� (����� CSIZE)
  (��稭�� � 0�� ����) �뫠 ࠢ�� NEEDCSUM.

  �. ⠪��:
  http://z0mbie.cjb.net/rvm2.zip/rvm2_7.arj -- 2000 䠩���-��񡮪 � ����,
                                           /test1522.com -- EICAR

*/

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <assert.h>

#define TARGETFILE      "trojan.bin"
#define FSIZE           68
#define CSIZE           0x20
#define NEEDCSUM        0x7C251A3D

typedef unsigned long   dword;
typedef unsigned char   byte;

dword csum(byte* data, dword len)
{
  dword c=0;
  while (len--)
  {
    c^=c<<8;
    c=(c&0xFFFFFF00)|((*data++)^(c>>24));
  }
  return c;
}

void main()
{
  byte buf[FSIZE];

  FILE*f=fopen(TARGETFILE,"r+b");
//FILE*f=fopen("test1522.com","r+b");
  assert(f!=NULL);
  fread(buf,1,FSIZE,f);

  dword c=csum(buf,CSIZE-4);
  buf[CSIZE-4]=(NEEDCSUM>>24)^c^(c>>16);
  buf[CSIZE-3]=(NEEDCSUM>>16)^c^(c>>8)^(c>>16)^(c>>24);
  buf[CSIZE-2]=(NEEDCSUM>>24)^(NEEDCSUM>>16)^(NEEDCSUM>>8);
  buf[CSIZE-1]=(NEEDCSUM>>24)^NEEDCSUM;

  assert(csum(buf,CSIZE)==NEEDCSUM);

  rewind(f);
  fwrite(buf,1,FSIZE,f);
  fclose(f);

  printf("success!\n");
}
