
dword csum(byte* data, dword len)
{
  dword c=0;
  while (len--)
  {
    c^=c<<8;                                 // rol+xor
    c=(c&0xFFFFFF00)|((*data++)^(c>>24));
  }
  return c;
}
