
// patch last 4 bytes

  dword c=csum(buf,CSIZE-4);
  buf[CSIZE-4]=(NEEDCSUM>>24)^c^(c>>16);
  buf[CSIZE-3]=(NEEDCSUM>>16)^c^(c>>8)^(c>>16)^(c>>24);
  buf[CSIZE-2]=(NEEDCSUM>>24)^(NEEDCSUM>>16)^(NEEDCSUM>>8);
  buf[CSIZE-1]=(NEEDCSUM>>24)^NEEDCSUM;
