
#define MAXBUFSIZE 32768
byte buf[MAXBUFSIZE];
byte bit[32][256*8];

// patch some last bytes

int buildcsum(byte* buf, dword csize, dword needcsum)
{

  memset(bit,0,sizeof(bit));

  for (dword i=0; i<csize; i++)
  {
    dword q=i<4?8:1;
    for (dword j=31; j>=q; j--)
      for (dword k=0; k<csize*8; k++)
        bit[j][k]^=bit[j-q][k];
    for (dword j=0; j<8; j++)
      bit[j][i*8+j]^=1;
  }

  dword c=0;
  for (dword i=0; i<32; i++)
  {
    for (dword j=0; j<csize*8; j++)
      if (bit[i][j])
        c^=((buf[j>>3]>>(j&7))&1)<<i;
  }
  if (c!=calccsum(buf,csize)) return 0;

  for (dword i=0; i<32; i++)
    for (dword j=0; j<csize*8; j++)
      if (bit[i][j])
        bit[i][j]=255;

  for (;;)
  {
    int c=0;
    for (dword i=0; i<32; i++)
    {
      if (((calccsum(buf,csize)^needcsum)>>i)&1)
      {
#define MINBYTE 0
        for (dword j=csize*8-1; j>=MINBYTE*8; j--) // [maxbit..minbit]
        if (bit[i][j])
        {
          bit[i][j]--;
          buf[j>>3]^=1<<(j&7);
          c++;
          goto ok;
        }
//      printf("***FAILED***");
        return 0;
  ok:
      }
    }
    if (!c) break;
  }

  return (calccsum(buf,csize)==needcsum);
}
