
dword calccsum(byte* data, dword size)
{
  dword c=0;
  for (dword i=0; i<size; i++)
  {
    if (i<4) c^=c<<8; else c^=c<<1;
    c^=data[i];
//  c^=(c<<(i<4?8:1))^data[i];
  }
  return c;
}

