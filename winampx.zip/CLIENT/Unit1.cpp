//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <windows.h>
#include <winsock2.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __cdecl err(char* fmt, ...);

#define printf_err err
#include "io.cpp"

void console(char* s)
{
  Form1->StaticText1->Caption = Form1->StaticText2->Caption;
  Form1->StaticText2->Caption = Form1->StaticText3->Caption;
  Form1->StaticText3->Caption = Form1->StaticText4->Caption;
  Form1->StaticText4->Caption = Form1->StaticText5->Caption;
  Form1->StaticText5->Caption = ">" + AnsiString(s);
}

void __cdecl err(char* fmt, ...)
{
  va_list va;
  va_start(va, fmt);
  static char s[2048];
  vsprintf(s, fmt, va);
  va_end(va);

  console(s);

  MessageBox(NULL, s, "WINAMPXX", MB_OK|MB_TASKMODAL|MB_ICONERROR);
}

void do_cmd_ex(char* cmd)
{
  console(cmd);

  static char host[1024];
  strcpy(host, Form1->Edit1->Text.c_str());

  char* res = do_cmd(host, cmd, 0);
  if (res != NULL)
  {
    console(res);
    free(res);
  }
} // do_cmd_ex

//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn1Click(TObject *Sender)
{
  do_cmd_ex("prev");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::BitBtn2Click(TObject *Sender)
{
  do_cmd_ex("play");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::BitBtn3Click(TObject *Sender)
{
  do_cmd_ex("pause");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::BitBtn4Click(TObject *Sender)
{
  do_cmd_ex("stop");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::BitBtn5Click(TObject *Sender)
{
  do_cmd_ex("next");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::BitBtn6Click(TObject *Sender)
{
  do_cmd_ex("winamp.exe");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::BitBtn7Click(TObject *Sender)
{
  static char cmd[512];
  strcpy(cmd, Edit2->Text.c_str());
  if (cmd[0])
    do_cmd_ex(cmd);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  WSADATA WSAData;
  if (WSAStartup(MAKEWORD(1,1), &WSAData) != 0)
    err("ERROR:WSAStartup() error %i\n", WSAGetLastError());

  static char s[1024];
  /*
  gethostname(s, sizeof(s));
  hostent* he = gethostbyname(s);
  if ((he != NULL) && (he->h_addrtype == AF_INET))
    Edit1->Text = inet_ntoa(*(in_addr*)he->h_addr_list[0]);
  */

  static char ini[1024];
  GetModuleFileName(NULL,ini,sizeof(ini)-1);
  if (strrchr(ini,'.')) *strrchr(ini,'.')=0;
  strcat(ini, ".ini");
  GetPrivateProfileString("winampxx","server","",s,sizeof(s)-1,ini);
  Edit1->Text = s;
  GetPrivateProfileString("winampxx","cmd","",s,sizeof(s)-1,ini);
  Edit2->Text = s;

  console("Welcome to WINAMPX -");
  console("remote winamp control");
  console("client/server suite.");
  console("");
  console("");
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
  WSACleanup();
}
//---------------------------------------------------------------------------




void __fastcall TForm1::BitBtn8Click(TObject *Sender)
{
  do_cmd_ex("shuffle");
}
//---------------------------------------------------------------------------

