
void bn_dumphex(char* s, DWORD x[])
{
  printf("%s",s);
  for (int i=BN_DWORD-1; i>=0; i--)
    printf("%08X",x[i]);
  printf("\n");
}

void bn_dumpdec(char* s, DWORD x[])
{
  char res[4096];
  char* resptr = &res[4095];
  *resptr=0;
  DWORD d[BN_DWORD], m[BN_DWORD], t[BN_DWORD], t0[BN_DWORD], t10[BN_DWORD];
  bn_mov0(t0);
  bn_movc(t10,10);
  bn_copy(t,x);
  do
  {
    bn_divmod(d,m,t,t10);
    *--resptr = '0'+m[0];
    bn_copy(t,d);
  }
  while (bn_cmp(t0,t)!=0);
  printf("%s%s\n",s,resptr);
}

void bn_movdec(DWORD x[], char* s)
{
  DWORD t[BN_DWORD],t10[BN_DWORD],c[BN_DWORD];
  bn_movc(t10,10);
  bn_mov0(x);
  for (DWORD i=0; i<strlen(s); i++)
  {
    bn_mul(t,x,t10);
    bn_copy(x,t);
    bn_movc(c,s[i]-'0');
    bn_add(x,c);
  }
}
