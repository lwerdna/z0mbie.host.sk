
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <string.h>

typedef unsigned long DWORD;

#include "den.h"

#include "bn-math.c"
#include "bn-io.c"

void main()
{
  DWORD d[BN_DWORD];
  DWORD e[BN_DWORD];
  DWORD n[BN_DWORD];

  memset(d,0,sizeof(d));
  memset(e,0,sizeof(e));
  memset(n,0,sizeof(n));
  memcpy(d,rsa_d,sizeof(rsa_d));
  memcpy(e,rsa_e,sizeof(rsa_e));
  memcpy(n,rsa_n,sizeof(rsa_n));

  bn_dumphex("d=",d);
  bn_dumphex("e=",e);
  bn_dumphex("n=",n);

  DWORD x[BN_DWORD];
  DWORD y[BN_DWORD];
  DWORD z[BN_DWORD];

  bn_mov0(x);
  strcpy((char*)&x,"Fucking Mini-RSA Library -- TO BETER FUCK AV ASSES !!!");

  printf("x=%s\n",(char*)&x);
  bn_dumpdec("x=",x);

  DWORD t;
  asm{
    extrn GetTickCount:PROC
    call GetTickCount
    mov t,eax
  }
  bn_powermod(y, x,e,n);
  asm{
    call GetTickCount
    sub t,eax
    neg t
  }
  printf("encr.time=%i\n",t);

  bn_dumpdec("y=",y);

  asm{
    extrn GetTickCount:PROC
    call GetTickCount
    mov t,eax
  }
  bn_powermod(z, y,d,n);
  asm{
    call GetTickCount
    sub t,eax
    neg t
  }
  printf("decr.time=%i\n",t);

  bn_dumpdec("z=",z);
  printf("z=%s\n",(char*)&z);

}
